var app = angular.module("app", ["ngRoute"]);

app.controller('MainCtrl', ['$scope', function ($scope) {
  console.log(1);
  $scope.initMenu = function(){
    console.log(2);
    if (typeof mCustomScrollbar != "undefined") {
      console.log(3);
      calcHeightItens();

      $("#nav-projeto").mCustomScrollbar({
        theme: "dark",
        scrollInertia: 600,
        axis: "y"
      });

      $(window).resize(function(){
        calcHeightItens();
        $("#nav-projeto").mCustomScrollbar("update");
      });
    }
  }
  $scope.initTop = function(){
    calcHeightItens();
    if (typeof mCustomScrollbar != "undefined") {
      $("#top-navbar").mCustomScrollbar({
        theme: "dark",
        scrollInertia: 600,
        axis: "x"
      });
  
      $(window).resize(function(){
        window.calcHeightItens();
        $("#top-navbar").mCustomScrollbar("update");
      });
    }
  }
}]);

app.controller('GlobalCtrl', function ($scope, $route, $location) {
  $("#nav-projeto .nav-itens .active").removeClass("active");
  $("#nav-projeto .nav-item a[href='#!"+$location.path()+"']").parent().addClass("active");

  if (typeof hljs != "undefined") {
		//hljs.initHighlightingOnLoad();
		//hljs.initLineNumbersOnLoad();

		$('pre code').each(function (i, block) {
			hljs.highlightBlock(block);
			if(!$(block).hasClass("nonumber")){
				hljs.lineNumbersBlock(block);
			}
		});
	}
}); 

app.config(($routeProvider) => {
  $routeProvider
    .when("/", {
      templateUrl: "./view/introducao.html",
      controller:"GlobalCtrl"
    })  
    .when("/phpunit", {
          templateUrl: "./view/phpunit.html",
          controller:"GlobalCtrl"
        })
    
    .when("/escrevendo-testes", {
      templateUrl: "./view/escrevendo-testes.html",
      controller:"GlobalCtrl"
    })
    .when("/ambiente", {
      templateUrl: "./view/ambiente.html",
      controller:"GlobalCtrl"
    })
    .when("/dubles-de-teste", {
      templateUrl: "./view/dubles-de-teste.html",
      controller:"GlobalCtrl"
    })
    .when("/assertions", {
      templateUrl: "./view/assertions.html",
      controller:"GlobalCtrl"
    })
    
    .when("/pyunit-introducao", {
      templateUrl: "./view/pyunit-introducao.html",
      controller:"GlobalCtrl"
    })
    .when("/escrevendo-testes-pyunit", {
      templateUrl: "./view/escrevendo-testes-pyunit.html",
      controller:"GlobalCtrl"
    })
    .when("/ambiente-pyunit", {
      templateUrl: "./view/ambiente-pyunit.html",
      controller:"GlobalCtrl"
    })
    .when("/objetos-mock-pyunit", {
      templateUrl: "./view/objetos-mock-pyunit.html",
      controller:"GlobalCtrl"
    })
    .when("/assertions-pyunit", {
      templateUrl: "./view/assertions-pyunit.html",
      controller:"GlobalCtrl"
    })
    .when("/Introducao-jest-js", {
      templateUrl: "./view/Introducao-jest-js.html",
      controller:"GlobalCtrl"
    })
    .when("/escrevendo-testes-jest-js", {
      templateUrl: "./view/escrevendo-testes-jest-js.html",
      controller:"GlobalCtrl"
    })
    .when("/funções-de-mock", {
      templateUrl: "./view/funções-de-mock.html",
      controller:"GlobalCtrl"
    })
    .when("/testes-de-codigo-assincrono", {
      templateUrl: "./view/testes-de-codigo-assincrono.html",
      controller:"GlobalCtrl"
    })
    .when("/introducao-junit", {
      templateUrl: "./view/introducao-junit.html",
      controller:"GlobalCtrl"
    })
    .when("/testes-junit", {
      templateUrl: "./view/escrevendo-testes-junit.html",
      controller:"GlobalCtrl"
    })
    .when("/ambiente-junit", {
      templateUrl: "./view/ambiente-junit.html",
      controller:"GlobalCtrl"
    })

    .when("/assertions-junit", {
      templateUrl: "./view/assertions-junit.html",
      controller:"GlobalCtrl"
    })
    .when("/introducao-nunit", {
      templateUrl: "./view/introducao-nunit.html",
      controller:"GlobalCtrl"
    })
    .when("/escrevendo-testes-nunit", {
      templateUrl: "./view/escrevendo-testes-nunit.html",
      controller:"GlobalCtrl"
    })
    .when("/executando-os-testes", {
      templateUrl: "./view/executando-os-testes.html",
      controller:"GlobalCtrl"
    })
    .when("/assertions-nunit", {
      templateUrl: "./view/assertions-nunit.html",
      controller:"GlobalCtrl"
    })
    
    .when('/outro', { template: 'no outro' });
    //.otherwise({ redirectTo: './view/introducao.html' })
});

app.component('barraNavegacao', {
  templateUrl: './templates/navigationBar.html'
})

app.component('menuTopo', {
  templateUrl: './templates/menuTopo.html'
})

//angular.bootstrap(document, [ app.name ])